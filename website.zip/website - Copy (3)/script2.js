function goToProduct(page){
	window.location.href = page;
}