let currentIndex = 0;

const images = [ "blz 2 folded.png", "blz 2.1.png", "blz 2 back.png", "blz 2.png" ];

function updateMainImage(index) { const mainImg = document.getElementById("mainImage"); const thumbnails = document.querySelectorAll(".thumbnail");

currentIndex = index; if (mainImg) { mainImg.src = images[currentIndex]; }

thumbnails.forEach((thumb, i) => { thumb.style.border = i === index ? "3px solid white" : "none"; }); }

function nextImage() { currentIndex = (currentIndex + 1) % images.length; updateMainImage(currentIndex); }

function previousImage() { currentIndex = (currentIndex - 1 + images.length) % images.length; updateMainImage(currentIndex); }

function changeImage(newSrc, index) { const mainImg = document.getElementById("mainImage"); if (mainImg) { mainImg.src = newSrc; } updateMainImage(index); }

function goToProduct(page) { window.location.href = page; }

document.addEventListener("DOMContentLoaded", function () { const cartCountSpan = document.getElementById("cartCount"); const savedCount = localStorage.getItem("cartCount") || 0; if (cartCountSpan) { cartCountSpan.textContent = savedCount; }

const addToCartBtn = document.getElementById("addToCartBtn");

if (addToCartBtn) { addToCartBtn.addEventListener("click", function () { let count = parseInt(localStorage.getItem("cartCount") || "0"); count += 1; localStorage.setItem("cartCount", count);

const cartCountSpan = document.getElementById("cartCount");
  if (cartCountSpan) {
    cartCountSpan.textContent = count;
  }

  const product = {
    name: document.getElementById("productName")?.textContent || "Unnamed Product",
    price: document.getElementById("productPrice")?.textContent || "R0.00",
    image: document.getElementById("mainImage")?.src || ""
  };

  let cartItems = JSON.parse(localStorage.getItem("cartItems") || "[]");
  cartItems.push(product);
  localStorage.setItem("cartItems", JSON.stringify(cartItems));
});

}

const cartPageItems = document.getElementById("cart-items"); const cartTotal = document.getElementById("cart-total");

if (cartPageItems && cartTotal) { let items = JSON.parse(localStorage.getItem("cartItems") || "[]"); let total = 0;

items.forEach((item) => {
  const itemDiv = document.createElement("div");
  itemDiv.style.background = "rgba(0,0,0,0.7)";
  itemDiv.style.padding = "1rem";
  itemDiv.style.borderRadius = "12px";
  itemDiv.style.textAlign = "center";

  const img = document.createElement("img");
  img.src = item.image;
  img.style.width = "100%";
  img.style.height = "180px";
  img.style.objectFit = "cover";
  img.style.borderRadius = "8px";

  const name = document.createElement("p");
  name.textContent = item.name;

  const price = document.createElement("p");
  price.textContent = item.price;

  itemDiv.appendChild(img);
  itemDiv.appendChild(name);
  itemDiv.appendChild(price);

  cartPageItems.appendChild(itemDiv);

  const priceValue = parseFloat(item.price.replace("R", "").replace(",", "").trim());
  if (!isNaN(priceValue)) {
    total += priceValue;
  }
});

cartTotal.textContent = "Total: R" + total.toFixed(2);

} });