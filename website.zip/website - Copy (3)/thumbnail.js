let currentIndex = 0;

const images = [
  "blz 2 folded.png",
  "blz 2.1.png",
  "blz 2 back.png",
  "blz 2.png"
];

function updateMainImage(index) {
  const mainImg = document.getElementById("mainImage");
  currentIndex = index;
  if (mainImg) {
    mainImg.src = images[currentIndex];
  }
}

function nextImage() {
  currentIndex = (currentIndex + 1) % images.length;
  updateMainImage(currentIndex);
}

function previousImage() {
  currentIndex = (currentIndex - 1 + images.length) % images.length;
  updateMainImage(currentIndex);
}

function changeImage(newSrc) {
  const mainImg = document.getElementById("mainImage");
  if (mainImg) {
    mainImg.src = newSrc;
    currentIndex = images.indexOf(newSrc);
  }
}