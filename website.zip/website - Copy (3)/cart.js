document.addEventListener("DOMContentLoaded", () => {
  const cartPageItems = document.getElementById("cart-items");
  const cartTotal = document.getElementById("cart-total");

  if (cartPageItems && cartTotal) {
    let items = JSON.parse(localStorage.getItem("cartItems") || "[]");
    let total = 0;

    items.forEach((item, index) => {
      const itemDiv = document.createElement("div");
      itemDiv.style.background = "rgba(0,0,0,0.7)";
      itemDiv.style.padding = "1rem";
      itemDiv.style.marginBottom = "1rem";
      itemDiv.style.borderRadius = "12px";
      itemDiv.style.textAlign = "center";

      const img = document.createElement("img");
      img.src = item.image;
      img.style.width = "100%";
      img.style.height = "180px";
      img.style.objectFit = "cover";
      img.style.borderRadius = "8px";

      const name = document.createElement("p");
      name.textContent = item.name;

      const price = document.createElement("p");
      price.textContent = item.price;

      const removeBtn = document.createElement("button");
      removeBtn.textContent = "Remove";
      removeBtn.style.backgroundColor = "#ff4444";
      removeBtn.style.color = "white";
      removeBtn.style.padding = "10px";
      removeBtn.style.border = "none";
      removeBtn.style.borderRadius = "8px";
      removeBtn.style.cursor = "pointer";
      removeBtn.onclick = () => {
        items.splice(index, 1);
        localStorage.setItem("cartItems", JSON.stringify(items));
        localStorage.setItem("cartCount", items.length);
        window.location.reload();
      };

      itemDiv.appendChild(img);
      itemDiv.appendChild(name);
      itemDiv.appendChild(price);
      itemDiv.appendChild(removeBtn);

      cartPageItems.appendChild(itemDiv);

      const priceValue = parseFloat(item.price.replace("R", "").replace(",", "").trim());
      if (!isNaN(priceValue)) total += priceValue;
    });

    cartTotal.textContent = "Total: R" + total.toFixed(2);
  }
});