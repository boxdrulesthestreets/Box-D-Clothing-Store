document.addEventListener("DOMContentLoaded", () => {
  const addToCartBtn = document.getElementById("addToCartBtn");

  if (addToCartBtn) {
    addToCartBtn.addEventListener("click", () => {
      const product = {
        name: document.getElementById("productName")?.textContent || "Unnamed Product",
        price: document.getElementById("productPrice")?.textContent || "R0.00",
        image: document.getElementById("mainImage")?.src || ""
      };

      let cartItems = JSON.parse(localStorage.getItem("cartItems") || "[]");
      cartItems.push(product);
      localStorage.setItem("cartItems", JSON.stringify(cartItems));

      let count = parseInt(localStorage.getItem("cartCount") || "0") + 1;
      localStorage.setItem("cartCount", count);

      const cartCountSpan = document.getElementById("cartCount");
      if (cartCountSpan) cartCountSpan.textContent = count;
    });
  }
});