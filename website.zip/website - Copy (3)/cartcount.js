document.addEventListener("DOMContentLoaded", () => {
  const cartCountSpan = document.getElementById("cartCount");
  const savedCount = localStorage.getItem("cartCount") || 0;
  if (cartCountSpan) {
    cartCountSpan.textContent = savedCount;
  }
});
